require 'test_helper'

class LabsHelperTest < ActionView::TestCase
end
