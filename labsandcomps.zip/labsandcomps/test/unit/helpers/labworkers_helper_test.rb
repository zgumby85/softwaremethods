require 'test_helper'

class LabworkersHelperTest < ActionView::TestCase
end
