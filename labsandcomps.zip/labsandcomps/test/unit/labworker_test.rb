require 'test_helper'

class LabworkerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
