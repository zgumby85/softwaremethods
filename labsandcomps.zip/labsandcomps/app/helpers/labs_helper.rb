module LabsHelper
end
